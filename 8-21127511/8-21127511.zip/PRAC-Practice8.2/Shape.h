#include "Point.h"
#pragma 1

class Shape
{
public:
    virtual void printInfo() = 0;
};


