#include "fraction.h"

// 21127511 - Nguyễn Quốc Huy

int main()
{
    const char *fileName = "output.txt";
    printInstructions();
    writeFile(fileName);
    return 0;
}