#include "fraction.h"

int main()
{
    printInstructions();
    vector<Fraction> vF;
    Output(vF);
    return 0;
}