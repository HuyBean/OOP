#ifndef LAB_2_2
#define LAB_2_2

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <time.h>

using namespace std;

void writeFile(const char *fileName);

int generateNum(int start, int end);

#endif