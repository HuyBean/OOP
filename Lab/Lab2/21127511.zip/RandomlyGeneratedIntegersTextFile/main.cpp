#include "file2.h"

// 21127511 - Nguyễn Quốc Huy

int main()
{
    const char *fileName = "output.txt";
    writeFile(fileName);
    return 0;
}