#ifndef ONE_SPACE_ONLY
#define ONE_SPACE_ONLY

#include "IRule.h"

class OneSpaceOnly : public IRule
{
private:
public:
    OneSpaceOnly()
    {
    }
    string toString()
    {
        return "OneSpaceOnly";
    }
    string rename(string name)
    {
        string result = name;
        for (int i = 0; i < result.length(); i++)
        {
            if (result[i] == ' ')
            {
                for (int j = i; j < result.length(); j++)
                {
                    result[j] = result[j + 1];
                }
            }
        }
        return result;
    }
};

#endif