#ifndef REMOVE_SPECIAL_CHARS
#define REMOVE_SPECIAL_CHARS

#include "IRule.h"

class RemoveSpecialChars : public IRule
{
private:
    int size;
    vector<char> chList;

public:
    RemoveSpecialChars()
    {
        size = 0;
    }
    RemoveSpecialChars(vector<char> vList)
    {
        size = vList.size();
        chList.resize(size);
        for (int i = 0; i < vList.size(); i++)
        {
            chList[i] = vList[i];
        }
    }
    RemoveSpecialChars(const RemoveSpecialChars &R)
    {
        size = R.chList.size();
        chList.resize(size);
        for (int i = 0; i < R.chList.size(); i++)
        {
            chList[i] = R.chList[i];
        }
    }
    string rename(string name)
    {
        string res = name;
        for (int i = 0; i < this->chList.size(); i++)
        {
            for (int j = 0; j < res.length(); j++)
            {
                if (chList[i] == res[j])
                {
                    for (int k = j; k < res.length() - 1; k++)
                    {
                        res[k] = res[k + 1];
                    }
                }
            }
        }
        return res;
    }
    string toString()
    {
        return "RemoveSpecialChars";
    }
};

#endif