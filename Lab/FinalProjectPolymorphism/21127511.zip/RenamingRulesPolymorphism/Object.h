#ifndef OBJECT_RENAME
#define OBJECT_RENAME

#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <fstream>
#include <sstream>


using namespace std;


class Object
{
    public:
    virtual string toString() = 0;
};

#endif