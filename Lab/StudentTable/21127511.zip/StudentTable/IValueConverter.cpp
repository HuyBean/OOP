#include "IValueConverter.h"

string IValueConverter::toString()
{
    return "IValueConverter";
}