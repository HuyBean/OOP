#include "Object.h"
#include "Bank.h"
#include "Information.h"

//21127511 - Nguyen Quoc Huy

//Utils files by an idea of teacher each lab excercise.

//All other source code made by own.

int main()
{
    Info info;
    info.readFile();
    // info.printListOfBank();
    info.Menu();
}