#include "3.3.h"
int main()
{
    return 0;
}