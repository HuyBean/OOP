#include "3.1.h"

// 21127511 - Nguyen Quoc Huy

int main()
{
    Fraction A();

}