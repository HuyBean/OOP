#include "3.2.h"
int main()
{
    return 0;
}